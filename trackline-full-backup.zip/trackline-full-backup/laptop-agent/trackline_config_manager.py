#!/usr/bin/env python3
"""
Trackline Config Manager — a small status/settings tool for a laptop
that's already been paired. Shows who a device is paired to and whether
it's actually syncing, lets you change the sync interval (updates both
config.json AND the actual Windows Scheduled Task, since Task Scheduler
doesn't read config.json — the interval is baked in at task-creation
time), and can trigger an immediate sync on demand.

Does not re-pair or uninstall — for those, use TracklineSetup or the
agent's own CLI flags directly.
"""

import json
import os
import sys
import platform
import subprocess
from pathlib import Path
from datetime import datetime, timezone


def _app_dir():
    """Same fixed, shared location trackline_agent.py and
    trackline_setup_gui.py use — duplicated here for the same reason as
    those two: this is a third separate compiled program and can't
    reliably import from the others once frozen with PyInstaller."""
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
    d = Path(base) / "TracklineAgent"
    d.mkdir(parents=True, exist_ok=True)
    return d

TASK_NAME = "TracklineScreenTimeSync"  # must match trackline_setup_gui.py's TASK_NAME exactly
SETUP_EXE_NAME = "TracklineSetup.exe"

def find_setup_exe():
    """Locates TracklineSetup.exe — same discovery approach as
    trackline_setup_gui.py's find_agent_exe(), and for the same reason:
    can't assume a single fixed folder layout. Checks the folder this
    Config Manager's own exe lives in, then the sibling-onedir-folder
    pattern PyInstaller --onedir actually produces when multiple tools are
    built into the same parent output folder. Unlike agent_exe_path,
    there's nowhere to persist this discovery across runs — config.json
    doesn't exist yet in the exact scenario this function matters for
    (the device isn't paired), so it's re-discovered each time."""
    if not getattr(sys, "frozen", False):
        return None
    own_folder = Path(sys.executable).parent

    same_folder_candidate = own_folder / SETUP_EXE_NAME
    if same_folder_candidate.exists():
        return same_folder_candidate

    sibling_candidate = own_folder.parent / "TracklineSetup" / SETUP_EXE_NAME
    if sibling_candidate.exists():
        return sibling_candidate

    return None

def launch_setup(setup_exe_path):
    """Launches the setup wizard as a separate, non-blocking process —
    the Config Manager doesn't wait for it to finish, since it's a GUI
    the person will interact with on their own. Returns (ok, message)."""
    try:
        subprocess.Popen([str(setup_exe_path)])
        return True, "Opening the setup wizard..."
    except Exception as e:
        return False, f"Could not open the setup wizard: {e}"


# ---------------------------------------------------------------------------
# Pure logic — reads local files only, no network calls, fully testable.
# ---------------------------------------------------------------------------

def read_config():
    path = _app_dir() / "config.json"
    if not path.exists():
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None

def read_status():
    path = _app_dir() / "status.json"
    if not path.exists():
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return None

def find_most_recent_sent_file():
    """Scans tracker/sent/ for the most recently modified file — a second,
    independent signal of "when did this device last actually sync
    successfully," corroborating (or contradicting) status.json."""
    sent_dir = _app_dir() / "tracker" / "sent"
    if not sent_dir.exists():
        return None
    files = list(sent_dir.glob("*.json"))
    if not files:
        return None
    return max(files, key=lambda p: p.stat().st_mtime)

def relative_time_label(iso_or_epoch):
    """Turns a timestamp into a short "X min/hours/days ago" label."""
    try:
        if isinstance(iso_or_epoch, (int, float)):
            when = datetime.fromtimestamp(iso_or_epoch, tz=timezone.utc)
        else:
            when = datetime.fromisoformat(str(iso_or_epoch).replace("Z", "+00:00"))
        delta = datetime.now(timezone.utc) - when
        minutes = delta.total_seconds() / 60
        if minutes < 1:
            return "just now"
        if minutes < 60:
            return f"{int(minutes)} min ago"
        hours = minutes / 60
        if hours < 24:
            return f"{int(hours)}h ago"
        return f"{int(hours/24)}d ago"
    except Exception:
        return "unknown"

def write_config(cfg):
    path = _app_dir() / "config.json"
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2)

def build_schtasks_change_command(minutes, task_name=TASK_NAME):
    """Task Scheduler doesn't read config.json — the interval is baked in
    at task-creation time — so changing it in config.json alone wouldn't
    do anything. This updates the actual task. Uses /change (not
    delete+recreate) to preserve everything else about the task (the
    command it runs, its trigger type) and only touch the interval."""
    return ["schtasks", "/change", "/tn", task_name, "/ri", str(minutes)]

def set_sync_interval(minutes):
    """Updates BOTH config.json and the real scheduled task. Returns
    (ok, message). If the scheduled task update fails (e.g. it was never
    set up, or was removed some other way), config.json still gets
    updated — better to have a correct config with a task that needs
    fixing separately than to block on a task that isn't there."""
    cfg = read_config()
    if not cfg:
        return False, "This device isn't paired."
    cfg["sync_interval_minutes"] = minutes
    write_config(cfg)

    if platform.system() != "Windows":
        return True, "Interval saved. Scheduled Task updates are Windows-only — update your cron/launchd entry manually."
    try:
        subprocess.run(build_schtasks_change_command(minutes), check=True, capture_output=True, text=True, timeout=15)
        return True, f"Sync interval updated to every {minutes} minutes."
    except subprocess.CalledProcessError as e:
        return False, f"Interval saved, but could not update the scheduled task: {e.stderr}"
    except Exception as e:
        return False, f"Interval saved, but could not update the scheduled task: {e}"

def sync_now():
    """Triggers an immediate sync using the agent path saved at pairing
    time. Returns (ok, message). Runs synchronously with a generous
    timeout — a real sync (querying ActivityWatch, pushing to the
    backend) should finish well within it."""
    cfg = read_config()
    if not cfg:
        return False, "This device isn't paired."
    agent_path = cfg.get("agent_exe_path")
    if not agent_path or not Path(agent_path).exists():
        return False, "Could not find the Trackline agent to run it — re-pairing (via TracklineSetup) will fix this."
    try:
        result = subprocess.run([agent_path, "--sync-once"], capture_output=True, text=True, timeout=60)
        if result.returncode == 0:
            return True, "Sync completed."
        return False, f"Sync did not complete cleanly: {result.stdout or result.stderr}"
    except subprocess.TimeoutExpired:
        return False, "Sync is taking longer than expected — check back in a minute."
    except Exception as e:
        return False, f"Could not run a sync: {e}"

def get_pairing_summary():
    """The single function the UI calls — returns everything needed to
    render the status view, or None if this device isn't paired at all.
    Pure, deterministic, testable without a display."""
    cfg = read_config()
    if not cfg:
        return None

    status = read_status()
    last_sent_file = find_most_recent_sent_file()

    return {
        "paired": True,
        "family_id": cfg.get("family_id", "unknown"),
        "member_name": cfg.get("member_name") or cfg.get("member_id", "unknown"),
        "member_id": cfg.get("member_id", "unknown"),
        "device_label": cfg.get("label") or cfg.get("hostname", "unknown"),
        "hostname": cfg.get("hostname", "unknown"),
        "backend_url": cfg.get("backend_url", "unknown"),
        "sync_interval_minutes": cfg.get("sync_interval_minutes", 30),
        "status": (status or {}).get("status", "unknown"),
        "status_detail": (status or {}).get("detail", ""),
        "status_checked_label": relative_time_label(status["checked_at"]) if status and status.get("checked_at") else "never",
        "last_successful_sync_label": relative_time_label(last_sent_file.stat().st_mtime) if last_sent_file else "never",
    }


# ---------------------------------------------------------------------------
# The GUI — thin on purpose, everything above this line is what's tested.
# ---------------------------------------------------------------------------

def run_gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    root = tk.Tk()
    root.title("Trackline — Device status")
    root.geometry("400x440")
    root.resizable(False, False)

    frame = ttk.Frame(root, padding=18)
    frame.pack(fill="both", expand=True)

    content = ttk.Frame(frame)
    content.pack(fill="both", expand=True)

    action_label = ttk.Label(frame, text="", wraplength=360, foreground="#5c5847")
    action_label.pack(pady=(6,0))

    interval_var = tk.StringVar()
    button_row = ttk.Frame(frame)

    def do_pair_now():
        setup_path = find_setup_exe()
        if not setup_path:
            picked = filedialog.askopenfilename(
                title=f"Locate {SETUP_EXE_NAME}",
                filetypes=[("TracklineSetup", SETUP_EXE_NAME), ("All files", "*.*")],
            )
            if not picked:
                return
            setup_path = picked
        ok, msg = launch_setup(setup_path)
        action_label.config(text=msg, foreground="#3d7a4f" if ok else "#a5323a")
        if ok:
            messagebox.showinfo("Setup opened", "Finish pairing in the setup window, then click Refresh here to see the updated status.")

    def render():
        for w in content.winfo_children():
            w.destroy()
        for w in button_row.winfo_children():
            w.destroy()
        summary = get_pairing_summary()

        if not summary:
            ttk.Label(content, text="This device is not paired yet.", font=("Segoe UI", 11, "bold")).pack(pady=(10,4))
            ttk.Label(content, text="Pair it with a family to start reporting screen time.", wraplength=320).pack(pady=(0,14))
            ttk.Button(content, text="Pair this device", command=do_pair_now).pack()
            ttk.Button(button_row, text="Refresh", command=render).pack(side="left")
            return

        status_colors = {"ok": "#3d7a4f", "failed": "#c98a2e", "revoked": "#a5323a", "unknown": "#8a8468"}
        status_labels = {"ok": "Syncing normally", "failed": "Last sync failed (will retry)", "revoked": "Pairing was removed — re-pair to resume", "unknown": "No sync attempted yet"}

        rows = [
            ("Paired to", f"{summary['member_name']}"),
            ("Family ID", summary["family_id"]),
            ("Device label", summary["device_label"]),
            ("Hostname", summary["hostname"]),
            ("Last sync attempt", summary["status_checked_label"]),
            ("Last successful sync", summary["last_successful_sync_label"]),
        ]
        for label, value in rows:
            row = ttk.Frame(content)
            row.pack(fill="x", pady=3)
            ttk.Label(row, text=label, width=18, foreground="#5c5847").pack(side="left")
            ttk.Label(row, text=str(value), font=("Segoe UI", 9, "bold")).pack(side="left")

        # Sync interval — editable, unlike the other rows above
        interval_row = ttk.Frame(content)
        interval_row.pack(fill="x", pady=(8,3))
        ttk.Label(interval_row, text="Sync interval", width=18, foreground="#5c5847").pack(side="left")
        interval_var.set(str(summary["sync_interval_minutes"]))
        interval_combo = ttk.Combobox(interval_row, textvariable=interval_var, values=["15","30","60","120"], width=6, state="normal")
        interval_combo.pack(side="left")
        ttk.Label(interval_row, text="min").pack(side="left", padx=(4,8))
        ttk.Button(interval_row, text="Apply", command=apply_interval).pack(side="left")

        status_row = ttk.Frame(content)
        status_row.pack(fill="x", pady=(12,0))
        color = status_colors.get(summary["status"], "#8a8468")
        text = status_labels.get(summary["status"], summary["status"])
        ttk.Label(status_row, text="●", foreground=color, font=("Segoe UI", 12)).pack(side="left")
        ttk.Label(status_row, text=text, foreground=color, font=("Segoe UI", 10, "bold")).pack(side="left", padx=(4,0))

        ttk.Button(button_row, text="Sync now", command=do_sync_now).pack(side="left", padx=(0,8))
        ttk.Button(button_row, text="Refresh", command=render).pack(side="left")

    def apply_interval():
        try:
            minutes = int(interval_var.get())
            if minutes < 1:
                raise ValueError()
        except ValueError:
            action_label.config(text="Enter a whole number of minutes.", foreground="#a5323a")
            return
        action_label.config(text="Updating...", foreground="#5c5847")
        root.update_idletasks()
        ok, msg = set_sync_interval(minutes)
        action_label.config(text=msg, foreground="#3d7a4f" if ok else "#a5323a")
        render()

    def do_sync_now():
        action_label.config(text="Syncing now — this can take a moment...", foreground="#5c5847")
        root.update_idletasks()
        ok, msg = sync_now()
        action_label.config(text=msg, foreground="#3d7a4f" if ok else "#a5323a")
        render()

    render()
    button_row.pack(pady=(14,0))

    root.mainloop()


if __name__ == "__main__":
    run_gui()
