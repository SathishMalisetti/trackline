# Trackline — Milestone 1 Deployment Guide & Project Record

**Purpose of this document:** a complete, saveable record of what Trackline
is, how it's built, and — most usefully — exactly what broke during the
first real deployment and how each thing was actually fixed. Keep this on
hand for the next time this project needs touching.

---

## 1. What Trackline is (Milestone 1 feature scope)

A family scheduling and task-tracking web app built as a single-page HTML/JS
app with a small serverless backend.

**Core features shipped in Milestone 1:**

- **Week Board** — visual weekly calendar, one column per family member,
  color-coded activities, automatic overlap/conflict detection (side-by-side
  layout + warning styling when two things clash for the same person).
- **Automatic drive/travel-time blocking** — mark an activity as needing a
  drive, and the driver's own calendar column automatically gets "in
  transit" blocks before and after, sized to the travel time.
- **Recurring activities** — weekly (any day), fortnightly (every 2 weeks,
  anchored to a chosen start date), monthly (day of month), or one-time,
  with per-occurrence "skip this date" for recurring ones (e.g. holidays).
- **Tasks** (originally called "Chores," renamed for clarity) — a separate
  recurring checklist system: daily / weekly / fortnightly / monthly / once,
  each with an optional due time, a "Starts on" date (so a new task can't
  retroactively appear as overdue on past dates), assigned to a specific
  family member, marked done with a recorded completion time.
- **Reusable Task Library** — autocomplete suggestions when adding a task;
  seeded with ~70 common household task names on family creation, grows
  automatically as new task names get typed.
- **Kid View** — a single person's day (schedule + tasks) in large,
  simple text, with a "copy to send" button as a stand-in for email/SMS.
- **Parent View** — the whole family's day as one time-sorted list, plus a
  quick done/pending readout of every kid's tasks, without needing the grid.
- **Per-person PIN login** — parents get full edit/delete rights; kids can
  view everything and create new activities/tasks, but can't edit or delete
  existing ones (their own or anyone else's).
- **Family onboarding** — a fresh deployment starts with a clean "set up your
  family" flow (no pre-seeded example family shown to real users), with an
  optional "just show me an example" demo path.
- **Multi-device join flow** — each family gets a short, human-typeable
  **Family ID** plus a **family password**, generated at setup. Any other
  device can join the same family (see its live, shared data) by entering
  those two things, then picking their own name from the member list and
  setting their own PIN.
- **Cloud sync** — all of the above is backed by a real database (Supabase),
  so every device pointed at the same deployment sees the same live data.

## 2. Architecture (final, working state)

```
Browser (index.html — no build step, plain HTML/CSS/JS)
      │
      │  fetch('/api/family-data')      same-origin, zero credentials shipped
      │  fetch('/api/chore-log')        to the browser
      ▼
Azure Static Web App (Free plan)
  ├─ index.html                          served as the site itself
  └─ /api  (Azure Functions, deployed alongside the site automatically)
        ├─ family-data/  GET, POST       the main family record
        └─ chore-log/    POST, DELETE    individual task-completion entries
              │
              │  SUPABASE_SERVICE_ROLE_KEY (app setting, server-only)
              ▼
        Supabase (hosted Postgres)
          ├─ families table    → id (= the Family ID), data (jsonb blob:
          │                       family info, members, events, tasks,
          │                       task library), password_hash implicitly
          │                       inside that blob
          └─ chore_logs table  → one row per completed task, indexed by
                                   family_id + chore_id + date
```

**Key design decisions and why:**

- **Credentials never reach the browser.** Early in this build, the app
  called Supabase directly from the browser using its public `anon` key.
  That key is *designed* to be public, but it still meant "View Source"
  showed the database URL and a working (if RLS-limited) key. The fix was
  routing everything through the Azure Function instead, using Supabase's
  `service_role` key — which bypasses Row Level Security entirely — kept
  purely server-side. The browser now only ever calls its own domain's
  `/api/family-data`.
- **`chore_logs` is a separate table from the main family blob.** Everything
  else (members, activities, task definitions, the task library) stays
  small and roughly constant in size — a family might have a few dozen of
  each, ever. Completion logs are different: they grow every single day,
  forever. Splitting them out means marking one task done is a single small
  database insert, not a rewrite of the entire family record.
- **One JSON blob per family, not a fully normalized relational schema.**
  Considered and deliberately rejected for now — a family's core data
  (members, events, task definitions) is small and bounded, so the extra
  complexity of a fully normalized schema (many tables, foreign keys, joins)
  wasn't worth it yet. If Trackline ever needs cross-family reporting or
  admin tooling, that would be the trigger to revisit this.
- **Family ID doubles as both the database primary key and the human-facing
  join code.** Generated as an 8-character code from an alphabet that
  excludes easily-confused characters (no `0`/`O`, `1`/`I`/`L`), so it's
  both a valid database key and something a person can type accurately.

## 3. Deploying from scratch (the clean path)

This is the *correct* sequence — see Section 4 for the specific wrong turns
this project actually took, in case any of them resurface.

### Step 1 — Supabase project

1. supabase.com → sign up (free) → **New project**.
2. SQL Editor → run `supabase-backend/schema.sql`, then
   `supabase-backend/schema-v2.sql` (creates `families`, then adds
   `chore_logs` and tightens security policies).
3. Project Settings → API → copy:
   - **Project URL**
   - **`service_role` key** (not `anon` — this one is the server-only
     secret; treat it like a password)

### Step 2 — GitHub repo

Repo containing, at minimum:
```
index.html
staticwebapp.config.json
api/
  host.json
  package.json
  family-data/{function.json,index.js}
  chore-log/{function.json,index.js}
```

### Step 3 — Azure Static Web App

1. Azure Portal → create **Static Web App** → **Free** plan.
2. Deployment source: **GitHub** → select the repo/branch.
3. Build presets: **Custom**. **App location**: `/`. **Api location**:
   `api`. **Output location**: (blank).
4. Deployment authorization: **Deployment token** (simpler and the
   Microsoft-recommended default over the GitHub/OIDC option for a first
   deployment).
5. Create. Azure auto-commits a GitHub Actions workflow file into the repo
   and triggers the first deployment.

### Step 4 — Verify `api_location` actually landed in the workflow file

**This is the single most important thing to check before assuming
anything is broken later** (see Gotcha #1 below). Open
`.github/workflows/*.yml` in the repo and confirm it contains:
```yaml
app_location: "/"
api_location: "api"
output_location: "."
```
If `api_location` is missing, add it and commit — this alone was the cause
of a full round of "why is my API 404ing" confusion during this build.

### Step 5 — Environment variables

Static Web App resource → **Environment Variables** (renamed from
"Configuration" in current Azure Portal) → **Add**:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`

### Step 6 — Test the API directly before testing the app

Before assuming the frontend is broken, hit the API directly in a browser
tab:
```
https://<your-app>.azurestaticapps.net/api/family-data?familyId=TEST123
```
Expected: `null` (plain text, not a 404 page, not a blank response). If you
get anything else, see the Troubleshooting appendix below — every failure
mode encountered during this build is documented there with its actual fix.

### Step 7 — Point the frontend

Nothing to configure in `index.html` for this — as of the backend-proxy
security fix, the frontend calls `/api/family-data` as a relative,
same-origin path automatically. No URL or key to paste in.

### Step 8 — Full test pass

1. Open the live URL → onboarding → create a family → note the Family ID
   shown → set your PIN.
2. Add a kid member in Settings.
3. Open the same URL on a second device/browser → **Join an existing
   family** → enter the Family ID + family password → confirm the kid
   appears in the profile picker → have them set their own PIN.
4. Mark a task done on one device → confirm Supabase's `chore_logs` table
   shows the new row → reload the app elsewhere and confirm it shows as
   done there too.

---

## 4. Troubleshooting appendix — what actually went wrong

Keeping this because these are exactly the kind of failures that look
identical from the outside but have completely different causes and fixes.

### Gotcha #1: "404 Not Found" on every `/api/*` call

**Symptom:** the site itself loaded fine, but any `/api/family-data` request
returned Azure's generic 404 page.

**Root cause:** the GitHub Actions workflow file that Azure auto-generated
was missing `api_location` entirely. The build log showed the smoking gun
plainly, if you knew where to look:
```
No Api directory specified. Azure Functions will not be created.
```
Even though the `api/` folder existed correctly in the repo the whole time,
Azure's build step never looked at it, because nothing told it to.

**Fix:** manually edit `.github/workflows/*.yml`, add `api_location: "api"`
next to the existing `app_location` and `output_location` lines, commit.
That edit itself triggers a redeploy.

**Lesson:** a 404 on an API route doesn't always mean the code is wrong —
check the *build log*, not just the deployed result, when a whole route
seems to not exist at all.

### Gotcha #2: API returns completely blank (status 200, 0 bytes)

**Symptom:** after fixing Gotcha #1, hitting the family-data URL directly
showed nothing at all — not `null`, not an error, just an empty response.
Confirmed via a HAR capture: `status 200`, `Content-Length: 0`,
`Content-Type: text/plain`.

**Root cause:** the Azure Functions Node.js runtime's `context.res.jsonBody`
convenience property was silently producing an empty response body in this
specific runtime version — most reliably reproduced on the "not found → return
null" code path, but not fully trusted afterward for any response.

**Fix:** stopped using `jsonBody` entirely. Every response is now built
explicitly:
```js
context.res = {
  status: 200,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(dataOrNull),
};
```
This has no ambiguity — `JSON.stringify(null)` reliably produces the
4-character string `"null"`, which showed up correctly once this change
shipped.

**Lesson:** when a response looks "successful" (200 status) but is
inexplicably empty, don't trust framework convenience shortcuts — inspect
the raw bytes (DevTools Network tab, or a HAR export) before assuming the
application logic itself is at fault.

### Gotcha #3: Multiple stray `index.html` files in the repo

**Symptom:** pushed an updated `index.html` more than once, but the live
site kept behaving like it was running old code.

**Root cause:** at some point, updates were saved as `index2.html`,
`index3.html`, `indexbackup.html`, etc. instead of overwriting `index.html`.
Azure Static Web Apps only ever serves the file literally named
`index.html` at the app root — every other variant just sat in the repo
unused, silently accumulating.

**Fix:** confirmed by opening `index.html` specifically on github.com and
searching for a known unique string from the intended update. Once
confirmed stale, replaced it directly.

**Lesson:** when "I pushed the fix but nothing changed," check that the
file that was actually edited is the file that's actually served — not a
same-looking sibling.

### Gotcha #4: Cosmos DB `public network access disabled` blocking connectivity

**Symptom:** early in the project (Cosmos DB era, since replaced by
Supabase), the Azure Function couldn't reach Cosmos DB at all once the
subscription's network policy disabled public access, and no VNet/private
endpoint option was available for Static Web Apps' *managed* Functions.

**Root cause:** Static Web Apps' built-in Functions (the `api/` folder
approach used here) fundamentally cannot do VNet integration or reach
private-endpoint-only resources — that capability only exists for
separately-hosted **Premium**-tier Azure Functions, which isn't free.

**Resolution:** this is part of why the project moved to Supabase
entirely — a fully separate platform from the Azure tenant's network
policies, with no VNet/private-endpoint concept to fight in the first
place. (A same-tenant workaround exists — Cosmos DB's "Accept connections
from within public Azure datacenters" exception — but it was superseded by
the Supabase move before that path was needed long-term.)

### Gotcha #5: Confusing `anon` key with `service_role` key

**Symptom/context:** not a bug exactly, but a real security gap caught in
review — the app initially called Supabase directly from the browser using
the public `anon` key, which is *designed* to be embeddable in frontend
code, but still meant the database URL and a working key were visible via
"View Source."

**Fix:** moved all database access behind the Azure Function, switched to
the `service_role` key (full access, bypasses Row Level Security — must
only ever live server-side), and removed the old permissive RLS policies
that had allowed the `anon` key to read/write directly.

**Lesson:** `anon`/public keys being "safe to expose" only holds if your
Row Level Security policies are actually locked down to match. Once this
project's policies were `using (true)` (allow anyone with the key), the key
being "public by design" stopped being a meaningful safety net.

---

## 5. What's next (not part of Milestone 1)

- Real server-side authentication (e.g. Supabase Auth) instead of the
  current lightweight PIN-in-browser model — a genuine security upgrade
  if this ever needs to hold more sensitive data.
- Actual email/SMS sending (data is already captured, provider not wired up).
- Offline support / local queueing of changes.
- A true multi-tenant single-URL product (central signup, admin dashboard
  across many families) — the current model is "one deployment, one active
  family, joinable by ID," which is a very different, much simpler thing
  than a real SaaS platform.
