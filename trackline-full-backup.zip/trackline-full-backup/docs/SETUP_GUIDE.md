# Trackline — Complete Setup Guide

Full backup snapshot as of August 16, 2026. Everything needed to deploy
Trackline from scratch, or to recover if you ever need to rebuild it.

---

## What's in this backup

```
html/            trackline.html — the whole frontend, one file
backend/         Azure Functions API + Supabase config
database/        Every SQL migration, in the order to run them
laptop-agent/    Python source for the screen-time tracking tools
docs/            This guide, plus the original detailed build docs
```

---

## 1. Database setup (Supabase)

Run these in Supabase's SQL Editor, **in this exact order** — each one
builds on the last:

1. `01-schema-base.sql` — the `families` table. Start here.
2. `02-schema-v2-chore-logs.sql` — task completion history.
3. `03-schema-v3-notifications-OPTIONAL-NOT-DEPLOYED.sql` — **skip this
   one for now.** It's the WhatsApp/email reminders feature — built, but
   deliberately never turned on. Only run it if you decide to pick that
   feature back up.
4. `04-schema-v4-shopping-trips.sql` — shopping trips + item library.
5. `05-schema-v5-relational.sql` — the big one: converts family data from
   a single JSON blob into real, indexed tables (members, events, chores,
   etc.). Auto-migrates existing data if you're running this on a
   database that already has families in it.
6. `06-schema-v7-device-tracking.sql` — screen-time tracking (devices +
   usage tables). Includes its own internal migrations (adds `title` and
   `category` columns) — safe to run even if you already have an older
   version of this table, it only adds what's missing.

Get your Supabase project URL and **service_role key** (Project Settings →
API) — you'll need both for the backend.

---

## 2. Backend setup (Azure Static Web Apps)

1. Push the entire `backend/` folder into your repo, with `api/` at the
   repo root (or wherever your Azure Static Web App is configured to look
   for it — check your GitHub Actions workflow's `api_location` setting).
2. In the Azure Portal, add two Application Settings to your Static Web
   App:
   - `SUPABASE_URL` — your project URL
   - `SUPABASE_SERVICE_ROLE_KEY` — the service_role key (never the anon
     key — this needs full access, and it stays server-side only)
3. Push to your connected branch — Azure auto-deploys the `api/` folder as
   Functions.

**12 endpoints total:**
- Core app: `family-data`, `chore-log`, `shopping-trip`, `export-family`,
  `join-family`
- Screen time: `device-pair`, `device-list`, `device-deregister`,
  `device-usage`, `device-usage-detail`, `device-usage-ingest`,
  `family-members`

---

## 3. Frontend

Just `html/trackline.html` — upload it as your site's `index.html` (or
whatever your Static Web App serves as the entry point). No build step, no
dependencies — it's one self-contained file.

**One thing to check**: near the top of the file, `TRACKLINE_AGENT_DOWNLOAD_URL`
should already point at your GitHub repo's raw file URL for the agent zip.
Confirm it's still correct if you've moved that file since.

---

## 4. Screen-time laptop tools

`laptop-agent/` has three Python scripts:

- **`trackline_agent.py`** — the background sync agent (queries
  ActivityWatch locally, pushes to Trackline every 30 min)
- **`trackline_setup_gui.py`** — the pairing wizard (family ID + password
  → pick a kid from a dropdown → done)
- **`trackline_config_manager.py`** — status viewer + Sync Now + interval
  control for an already-paired device

**Build as `--onedir`, not `--onefile`** — `--onefile` has a confirmed
"Bad Image" antivirus-interference issue on Windows; `--onedir` avoids it
entirely:

```bash
pip install pyinstaller requests tzlocal

pyinstaller --onedir --windowed --name TracklineSetup trackline_setup_gui.py
pyinstaller --onedir --console --name TracklineAgent trackline_agent.py
pyinstaller --onedir --windowed --name TracklineConfigManager trackline_config_manager.py
```

Zip up the three resulting `dist/` folders together — that's what goes up
as the downloadable release asset, and what a parent extracts into
`C:\trackline` per the in-app instructions.

**⚠ Known limitation, currently accepted as-is**: `trackline_setup_gui.py`
in this backup does **not** include the "deregister before re-pairing"
fix. That fix was tried (twice) and correlated with a worse regression
(pairing silently not completing), so per explicit decision this was
rolled back to the last confirmed-working version. **Practical
consequence**: re-running setup on an already-paired device will create a
duplicate device registration rather than replacing the old one. Avoid
doing that for now; if you need to re-pair a device, manually remove the
old entry afterward via Settings → "Manage registered devices."

---

## 5. What's deliberately not included / not built

- **ActivityWatch download link** — removed from the in-app instructions
  pending consent from whoever needs to approve it; add back once that's
  sorted.
- **Web-watcher browser extension** — not installed anywhere yet, so
  browser time still aggregates as lump `chrome.exe`/`msedge.exe`, no
  per-site breakdown.
- **Real mobile tracking** — doesn't exist. The Screen Time UI shows a
  "Mobile tracking is under construction" note for real families; the
  Example Family's mobile data is explicitly labeled as illustrative
  sample data only.
- **WhatsApp/email notifications** — fully built (see the optional schema
  above and `notify-backend` if you have that folder from earlier), but
  never turned on, per an earlier explicit decision to hold off.
- **One-exe-does-everything / auto-install to Program Files** — discussed,
  not built. Program Files needs admin elevation; a per-user location
  (`%LocalAppData%\Programs\Trackline\`) was proposed as the alternative
  if this gets picked back up.

---

## For deeper detail on any specific piece

`docs/README.md` and `docs/MILESTONE_1_DEPLOYMENT_GUIDE.md` cover the core
app's build history in detail. `docs/DEVICE_TRACKING_SETUP.md` is the full,
round-by-round history of the screen-time tracking system — every bug
found, every fix, every test — useful if something breaks and you want to
understand *why* a particular piece of code exists the way it does.
