-- Trackline — Supabase schema v2
-- Run this in your Supabase project's SQL Editor.
-- Safe to run even if you already ran the original schema.sql — it only adds
-- what's missing and tightens security on what already exists.

-- ============================================================================
-- 1. New table: chore_logs
-- Completion history — one row per "task marked done." This grows every day
-- forever, which is exactly why it's a separate table instead of living
-- inside the big JSON blob in `families`: checking off one task is now a
-- single small insert, not a rewrite of the whole family record.
-- ============================================================================
create table if not exists chore_logs (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  chore_id text not null,
  date date not null,
  completed_at text not null,
  logged_by text,
  created_at timestamptz not null default now()
);

-- Speeds up the two access patterns that matter: "all logs for this family"
-- (used when loading the app) and "the log for this specific task on this
-- specific day" (used when checking whether something's already done).
create index if not exists idx_chore_logs_family on chore_logs(family_id);
create index if not exists idx_chore_logs_family_chore_date on chore_logs(family_id, chore_id, date);

alter table chore_logs enable row level security;
-- No policies defined on purpose: only the backend (using the service_role
-- key, which bypasses Row Level Security entirely by design) ever touches
-- this table now. RLS being "on" with zero policies means the anon key -
-- even if someone found it - gets denied by default, which is the point.

-- ============================================================================
-- 2. Tighten `families` — remove the old policies that let the anon key
-- (public, embeddable-in-frontend-by-design) read/write directly.
-- As of this update, the browser never talks to Supabase directly anymore —
-- everything goes through the backend Function using the service_role key
-- instead. These old policies are no longer needed and are a real exposure
-- if the anon key were ever found, so we're removing them.
-- ============================================================================
drop policy if exists "allow read by id" on families;
drop policy if exists "allow insert" on families;
drop policy if exists "allow update" on families;

-- families keeps RLS enabled with no policies now too — same reasoning as
-- chore_logs above: only service_role (server-side) can touch it.
