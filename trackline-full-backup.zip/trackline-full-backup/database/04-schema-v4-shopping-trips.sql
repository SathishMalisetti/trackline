-- Trackline — Shopping Trips schema
-- Run this in Supabase SQL Editor, in addition to your existing schema files.

create table if not exists shopping_lists (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  date date,               -- the trip's date, kept as its own column (not just
                            -- inside data) so it's indexable/queryable directly
  data jsonb not null,      -- the whole trip object: {id,choreId,name,date,
                            -- memberId,status,items:[...],createdBy,createdAt}
  updated_at timestamptz not null default now()
);

create index if not exists idx_shopping_lists_family on shopping_lists(family_id);
create index if not exists idx_shopping_lists_family_date on shopping_lists(family_id, date);

alter table shopping_lists enable row level security;
-- No policies defined on purpose — only the backend (service_role, which
-- bypasses RLS) ever touches this table, same reasoning as chore_logs.
