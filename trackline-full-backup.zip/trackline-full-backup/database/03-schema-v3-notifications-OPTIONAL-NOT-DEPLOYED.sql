-- Trackline — Notifications schema (Milestone 2: email + WhatsApp reminders)
-- Run this in Supabase SQL Editor, in addition to schema.sql and schema-v2.sql.

create table if not exists notifications_sent (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  kind text not null,        -- 'activity_reminder' | 'task_reminder' | 'daily_digest'
  ref_id text not null,      -- event id / chore id / member id (for digest, one per member)
  ref_date date not null,    -- the calendar date this notification belongs to
  sent_at timestamptz not null default now()
);

-- This unique constraint IS the duplicate-prevention mechanism: the scheduler
-- tries to INSERT before sending anything. If a row for this exact
-- (family, kind, thing, date) already exists, the insert fails with a
-- conflict and the scheduler skips sending — even if it's a different run,
-- a retry, or an overlapping invocation.
create unique index if not exists uniq_notification
  on notifications_sent(family_id, kind, ref_id, ref_date);

create index if not exists idx_notifications_family_date
  on notifications_sent(family_id, ref_date);

alter table notifications_sent enable row level security;
-- No policies defined on purpose — only the scheduler (using service_role,
-- which bypasses RLS) ever touches this table.
