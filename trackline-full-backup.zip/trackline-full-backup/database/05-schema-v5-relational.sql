-- Trackline — Relational schema (v6)
-- Replaces the single `families.data jsonb` blob with real, indexed tables.
-- Run this AFTER schema.sql, schema-v2.sql, schema-v3-notifications.sql (if
-- used), and schema-v4-shopping-trips.sql — this does not remove those
-- tables (chore_logs, shopping_lists stay exactly as they are, they were
-- already properly normalized).

-- ============================================================================
-- 1. Extend `families` with real columns instead of one jsonb blob for
--    everything. The jsonb `data` column is kept for now as a safety-net
--    backup during migration — see Step 5 below for when it's safe to drop.
-- ============================================================================
alter table families add column if not exists name text;
alter table families add column if not exists primary_holder_name text;
alter table families add column if not exists primary_holder_email text;
alter table families add column if not exists primary_holder_phone text;
alter table families add column if not exists password_hash text;

-- ============================================================================
-- 2. Real tables for everything that used to live inside the blob.
-- ============================================================================
create table if not exists members (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  name text not null,
  role text not null,
  color text,
  pin_hash text,
  email text,
  phone text,
  created_at timestamptz not null default now()
);
create index if not exists idx_members_family on members(family_id);

create table if not exists events (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  member_id text,
  title text not null,
  recurrence text not null,
  day int,
  date date,
  skip_dates jsonb not null default '[]',
  occurrence_overrides jsonb not null default '[]',
  start_min int,
  end_min int,
  location text,
  notes text,
  needs_drive boolean not null default false,
  driver_id text,
  travel_min int not null default 0,
  color text,
  created_at timestamptz not null default now()
);
create index if not exists idx_events_family on events(family_id);
create index if not exists idx_events_family_member on events(family_id, member_id);

create table if not exists chores (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  member_id text,
  title text not null,
  frequency text not null,
  days jsonb not null default '[]',
  day_of_month int,
  start_date date,
  due_date date,
  due_time text,
  points int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists idx_chores_family on chores(family_id);
create index if not exists idx_chores_family_member on chores(family_id, member_id);

create table if not exists chore_library_items (
  id bigserial primary key,
  family_id text not null references families(id) on delete cascade,
  title text not null,
  unique(family_id, title)
);
create index if not exists idx_chore_lib_family on chore_library_items(family_id);

create table if not exists quick_list_items (
  id text primary key,
  family_id text not null references families(id) on delete cascade,
  name text not null,
  added_by text,
  created_at timestamptz not null default now()
);
create index if not exists idx_quicklist_family on quick_list_items(family_id);

create table if not exists shopping_item_library_items (
  id bigserial primary key,
  family_id text not null references families(id) on delete cascade,
  name text not null,
  unique(family_id, name)
);
create index if not exists idx_shop_lib_family on shopping_item_library_items(family_id);

-- All new tables get RLS enabled with zero policies — same reasoning as
-- chore_logs and shopping_lists: only the backend (service_role, which
-- bypasses RLS) ever touches these directly.
alter table members enable row level security;
alter table events enable row level security;
alter table chores enable row level security;
alter table chore_library_items enable row level security;
alter table quick_list_items enable row level security;
alter table shopping_item_library_items enable row level security;

-- ============================================================================
-- 3. save_family_data — atomically decomposes an incoming JSON payload
--    across all the real tables in one transaction (Postgres functions run
--    as a single transaction automatically). This is what the API calls
--    on every save, instead of writing one giant JSON blob.
-- ============================================================================
create or replace function save_family_data(p_family_id text, p_data jsonb)
returns void
language plpgsql
security definer
as $$
begin
  insert into families (id, name, primary_holder_name, primary_holder_email, primary_holder_phone, password_hash, updated_at)
  values (
    p_family_id,
    p_data->'family'->>'name',
    p_data->'family'->>'primaryHolderName',
    p_data->'family'->>'primaryHolderEmail',
    p_data->'family'->>'primaryHolderPhone',
    p_data->'family'->>'passwordHash',
    now()
  )
  on conflict (id) do update set
    name = excluded.name,
    primary_holder_name = excluded.primary_holder_name,
    primary_holder_email = excluded.primary_holder_email,
    primary_holder_phone = excluded.primary_holder_phone,
    password_hash = excluded.password_hash,
    updated_at = now();

  delete from members where family_id = p_family_id;
  insert into members (id, family_id, name, role, color, pin_hash, email, phone)
  select m->>'id', p_family_id, m->>'name', m->>'role', m->>'color', m->>'pinHash', m->>'email', m->>'phone'
  from jsonb_array_elements(coalesce(p_data->'members','[]'::jsonb)) as m;

  delete from events where family_id = p_family_id;
  insert into events (id, family_id, member_id, title, recurrence, day, date, skip_dates, occurrence_overrides, start_min, end_min, location, notes, needs_drive, driver_id, travel_min, color)
  select
    e->>'id', p_family_id, e->>'memberId', e->>'title', e->>'recurrence',
    nullif(e->>'day','')::int, nullif(e->>'date','')::date,
    coalesce(e->'skipDates','[]'::jsonb), coalesce(e->'occurrenceOverrides','[]'::jsonb),
    nullif(e->>'start','')::int, nullif(e->>'end','')::int,
    e->>'location', e->>'notes',
    coalesce((e->>'needsDrive')::boolean,false), e->>'driverId', coalesce(nullif(e->>'travelMin','')::int,0),
    e->>'color'
  from jsonb_array_elements(coalesce(p_data->'events','[]'::jsonb)) as e;

  delete from chores where family_id = p_family_id;
  insert into chores (id, family_id, member_id, title, frequency, days, day_of_month, start_date, due_date, due_time, points, active)
  select
    c->>'id', p_family_id, c->>'memberId', c->>'title', c->>'frequency',
    coalesce(c->'days','[]'::jsonb), nullif(c->>'dayOfMonth','')::int,
    nullif(c->>'startDate','')::date, nullif(c->>'dueDate','')::date, c->>'dueTime',
    coalesce(nullif(c->>'points','')::int,0), coalesce((c->>'active')::boolean,true)
  from jsonb_array_elements(coalesce(p_data->'chores','[]'::jsonb)) as c;

  delete from chore_library_items where family_id = p_family_id;
  insert into chore_library_items (family_id, title)
  select p_family_id, x from jsonb_array_elements_text(coalesce(p_data->'choreLibrary','[]'::jsonb)) as x
  on conflict do nothing;

  delete from quick_list_items where family_id = p_family_id;
  insert into quick_list_items (id, family_id, name, added_by)
  select i->>'id', p_family_id, i->>'name', i->>'addedBy'
  from jsonb_array_elements(coalesce(p_data->'shoppingList','[]'::jsonb)) as i;

  delete from shopping_item_library_items where family_id = p_family_id;
  insert into shopping_item_library_items (family_id, name)
  select p_family_id, x from jsonb_array_elements_text(coalesce(p_data->'shoppingItemLibrary','[]'::jsonb)) as x
  on conflict do nothing;
end;
$$;

-- ============================================================================
-- 4. get_family_data — reassembles the real tables back into the exact same
--    JSON shape the frontend already expects. The frontend needs ZERO
--    changes for this — the wire format is identical, only how it's stored
--    in the database changed.
-- ============================================================================
create or replace function get_family_data(p_family_id text)
returns jsonb
language plpgsql
security definer
as $$
declare
  fam record;
  result jsonb;
begin
  select * into fam from families where id = p_family_id;
  if not found then
    return null;
  end if;

  select jsonb_build_object(
    'family', jsonb_build_object(
      'id', fam.id, 'name', fam.name, 'primaryHolderName', fam.primary_holder_name,
      'primaryHolderEmail', fam.primary_holder_email, 'primaryHolderPhone', fam.primary_holder_phone,
      'passwordHash', fam.password_hash
    ),
    'members', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', id, 'name', name, 'role', role, 'color', color,
        'pinHash', pin_hash, 'email', email, 'phone', phone
      )) from members where family_id = p_family_id
    ), '[]'::jsonb),
    'events', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', id, 'memberId', member_id, 'title', title, 'recurrence', recurrence,
        'day', day, 'date', date, 'skipDates', skip_dates, 'occurrenceOverrides', occurrence_overrides,
        'start', start_min, 'end', end_min, 'location', location, 'notes', notes,
        'needsDrive', needs_drive, 'driverId', driver_id, 'travelMin', travel_min, 'color', color
      )) from events where family_id = p_family_id
    ), '[]'::jsonb),
    'chores', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', id, 'memberId', member_id, 'title', title, 'frequency', frequency,
        'days', days, 'dayOfMonth', day_of_month, 'startDate', start_date, 'dueDate', due_date,
        'dueTime', due_time, 'points', points, 'active', active
      )) from chores where family_id = p_family_id
    ), '[]'::jsonb),
    'choreLibrary', coalesce((
      select jsonb_agg(title) from chore_library_items where family_id = p_family_id
    ), '[]'::jsonb),
    'shoppingList', coalesce((
      select jsonb_agg(jsonb_build_object('id', id, 'name', name, 'addedBy', added_by))
      from quick_list_items where family_id = p_family_id
    ), '[]'::jsonb),
    'shoppingItemLibrary', coalesce((
      select jsonb_agg(name) from shopping_item_library_items where family_id = p_family_id
    ), '[]'::jsonb)
  ) into result;

  return result;
end;
$$;

-- ============================================================================
-- 5. One-time migration: move any existing data sitting in the old
--    `families.data` jsonb blob into the new tables, for families created
--    before this update. Safe to run even if there's nothing to migrate.
-- ============================================================================
do $$
declare
  r record;
begin
  for r in select id, data from families where data is not null loop
    perform save_family_data(r.id, r.data);
  end loop;
end $$;

-- ============================================================================
-- 6. Once you've confirmed (via the app, and via Table Editor) that data
--    migrated correctly, you can drop the old blob column entirely:
--
--    alter table families drop column data;
--
-- Not run automatically here on purpose — verify first, drop later.
-- ============================================================================
